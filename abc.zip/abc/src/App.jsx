import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import heroImg from './assets/hero.png'
import './App.css'
import Button from '@mui/material/Button';
import SearchBox from './SearchBox'


function App() {
  return (
    <>
      <SearchBox></SearchBox>
    </>
  )
}

export default App
